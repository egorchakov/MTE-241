#ifndef __QUICKSORT_H__
#define __QUICKSORT_H__

#include "array_tools.h"

void quicksort( array_t );
void quicksort_sem( array_t );

#endif